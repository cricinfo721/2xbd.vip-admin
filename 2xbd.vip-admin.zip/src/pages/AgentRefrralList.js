import React from 'react'

const AgentRefrralList = () => {
  return (
    <div>AgentRefrralList</div>
  )
}

export default AgentRefrralList